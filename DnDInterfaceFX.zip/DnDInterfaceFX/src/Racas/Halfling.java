package Racas;

public class Halfling extends Racas{


    
}
