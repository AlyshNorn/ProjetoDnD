package Racas;

public class Gnomo extends Racas{


    
}
