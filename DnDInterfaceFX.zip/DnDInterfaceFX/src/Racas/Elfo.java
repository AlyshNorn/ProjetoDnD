package Racas;

public class Elfo extends Racas{
    
}
