package dndinterfacefx;

public class ListasSubRacas {

    private String [] anao = {"Da Colina", "Da Montanha"};
    private String [] Elfo = {"High Elves", "Da Floresta", "Drow"};
    private String [] Halfling = {"Pés Leves", "Robusto"};
    private String [] Draconato = {"Azul", "Branco", "Bronze", "Cobre", "Latão", "Negro", "Ouro", "Prata", "Verde", "Vermelho"};
    private String [] Gnomo = {"Da Floresta", "Das Rochas"};

    public String[] getAnao() {
        return anao;
    }
    public void setAnao(String[] anao) {
        this.anao = anao;
    }

    public String[] getElfo() {
        return Elfo;
    }
    public void setElfo(String[] Elfo) {
        this.Elfo = Elfo;
    }

    public String[] getHalfling() {
        return Halfling;
    }
    public void setHalfling(String[] Halfling) {
        this.Halfling = Halfling;
    }

    public String[] getDraconato() {
        return Draconato;
    }
    public void setDraconato(String[] Draconato) {
        this.Draconato = Draconato;
    }
    
    public String[] getGnomo() {
        return Gnomo;
    }
    public void setGnomo(String[] Gnomo) {
        this.Gnomo = Gnomo;
    }
    
}
