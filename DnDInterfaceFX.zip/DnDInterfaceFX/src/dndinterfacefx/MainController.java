package dndinterfacefx;

import StatusPersornagem.TirarStatus;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;

public class MainController implements Initializable {
    
    @FXML private ListView<String>  lvStatus;
    @FXML private ComboBox<String>  bxRaca;
    @FXML private ComboBox<String>  bxSubRaca;
    @FXML private ComboBox<String>  bxClasse;
    @FXML private Button btSubRaca;
    @FXML private Label txSubRaca;
    @FXML private Button btTrocaForca;
    @FXML private Button btTrocaDestreza;
    @FXML private Button btTrocaConstituicao;
    @FXML private Button btTrocaInteligencia;
    @FXML private Button btTrocaSabedoria;
    @FXML private Button btTrocaCarisma;
    
    
    Random random = new Random();
    ListasSubRacas SR = new ListasSubRacas();
    TirarStatus TS = new TirarStatus();
    
    private int ValorSubstituicaoStatus = 0;
    private int ValorSubstituicaoModStatus = 0;
    private boolean trocaDisponivel =true; 
    private String StatusTroca = "";
    
    private final String [] Raca = {"Anão","Elfo","Halfling","Humano","Draconato","Gnomo","Meio-Elfo","Meio-Orc","Tiefling"};
    private final String [] Classe = {"Bárbaro","Bardo","Bruxo","Clérigo","Druida","Feiticeiro","Guerreiro","Ladino","Mago","Monge","Paladino","Patrulheiro"};
    private String [] Status;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setSubRacaInvisivel();
        bxRaca.getItems().addAll(Raca);
        bxClasse.getItems().addAll(Classe);
        aleatorizarStatus();
    }    
    
    public void subRacas(ActionEvent event){
        String raca = bxRaca.getValue();
        switch(raca){
            case "Anão":
                setSubRacaVisivel();
                bxSubRaca.getItems().clear();
                bxSubRaca.getItems().addAll(SR.getAnao());
                break;
            case "Elfo":
                setSubRacaVisivel();
                bxSubRaca.getItems().clear();                
                bxSubRaca.getItems().addAll(SR.getElfo());
                break;
            case "Halfling":
                setSubRacaVisivel();
                bxSubRaca.getItems().clear();
                bxSubRaca.getItems().addAll(SR.getHalfling());
                break;
            case "Draconato":
                setSubRacaVisivel();
                bxSubRaca.getItems().clear();
                bxSubRaca.getItems().addAll(SR.getDraconato());
                break;
            case "Gnomo":
                setSubRacaVisivel();
                bxSubRaca.getItems().clear();
                bxSubRaca.getItems().addAll(SR.getGnomo());
                break;
            default:
                bxSubRaca.getItems().clear();
                setSubRacaInvisivel();
        }
    }

    public void setSubRacaInvisivel (){
        txSubRaca.setVisible(false);
        btSubRaca.setVisible(false);
        bxSubRaca.setVisible(false);
    }
    public void setSubRacaVisivel (){
        txSubRaca.setVisible(true);
        btSubRaca.setVisible(true);
        bxSubRaca.setVisible(true);
    }
    
    public void superRandomize(){
        aleatorizarRacas();
        aleatorizarClasse();
        aleatorizarStatus();
        if(("Anão".equals(bxRaca.getValue())) 
                || ("Elfo".equals(bxRaca.getValue()))
                || ("Halfling".equals(bxRaca.getValue()))
                || ("Draconato".equals(bxRaca.getValue()))
                || ("Gnomo".equals(bxRaca.getValue()))
                ){
            aleatorizarSubRacas();
        }
    }
    
    public void aleatorizarRacas(){ 
        bxRaca.setValue(escolherUma(Raca));
    }
    public void aleatorizarClasse(){ 
        bxClasse.setValue(escolherUma(Classe));
    }
    public void aleatorizarStatus(){
        lvStatus.getItems().clear(); 
        Status = TS.TirareOrganizarInfo();
        lvStatus.getItems().addAll(Status);
    }
    public void aleatorizarSubRacas(){
        String raca = bxRaca.getValue();
        switch(raca){
            case "Anão":
                bxSubRaca.setValue(escolherUma(SR.getAnao()));
                break;
            case "Elfo":
                bxSubRaca.setValue(escolherUma(SR.getElfo()));
                break;
            case "Halfling":
                bxSubRaca.setValue(escolherUma(SR.getHalfling()));
                break;
            case "Draconato":
                bxSubRaca.setValue(escolherUma(SR.getDraconato()));
                break;
            case "Gnomo":
                bxSubRaca.setValue(escolherUma(SR.getGnomo()));
                break;   
            default:
                System.out.println("Nada Aq");
        } 
    }

    public void trocarForca (){
        if(isTrocaDisponivel()){
            setValorSubstituicaoStatus(TS.getForca());
            setValorSubstituicaoModStatus(TS.getMODForca());
            setTrocaDisponivel(false);
            setStatusTroca("Força");
            btTrocaForca.setVisible(false);
        }else{
            switch(getStatusTroca()){
                case "Destreza":
                    TS.setDestreza(TS.getForca());
                    TS.setMODDestreza(TS.getMODForca());
                    TS.setForca(getValorSubstituicaoStatus());
                    TS.setMODForca(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaDestreza.setVisible(true);
                    break;
                case "Constituição":
                    TS.setConstituicao(TS.getForca());
                    TS.setMODConstituicao(TS.getMODForca());
                    TS.setForca(getValorSubstituicaoStatus());
                    TS.setMODForca(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaConstituicao.setVisible(true);
                    break;
                case "Inteligência":
                    TS.setInteligencia(TS.getForca());
                    TS.setMODInteligencia(TS.getMODForca());
                    TS.setForca(getValorSubstituicaoStatus());
                    TS.setMODForca(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaInteligencia.setVisible(true);
                    break;
                case "Sabedoria":
                    TS.setSabedoria(TS.getForca());
                    TS.setMODSabedoria(TS.getMODForca());
                    TS.setForca(getValorSubstituicaoStatus());
                    TS.setMODForca(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaSabedoria.setVisible(true);
                    break;
                case "Carisma":
                    TS.setCarisma(TS.getForca());
                    TS.setMODCarisma(TS.getMODForca());
                    TS.setForca(getValorSubstituicaoStatus());
                    TS.setMODForca(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaCarisma.setVisible(true);
                    break;
            }
        }
    }
    public void trocarDestreza (){
        if(isTrocaDisponivel()){
            setValorSubstituicaoStatus(TS.getDestreza());
            setValorSubstituicaoModStatus(TS.getMODDestreza());
            setTrocaDisponivel(false);
            setStatusTroca("Destreza");
            btTrocaDestreza.setVisible(false);
        }else{
            switch(getStatusTroca()){
                case "Força":
                    TS.setForca(TS.getDestreza());
                    TS.setMODForca(TS.getMODDestreza());
                    TS.setDestreza(getValorSubstituicaoStatus());
                    TS.setMODDestreza(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaForca.setVisible(true);
                    break;
                case "Constituição":
                    TS.setConstituicao(TS.getDestreza());
                    TS.setMODConstituicao(TS.getMODDestreza());
                    TS.setDestreza(getValorSubstituicaoStatus());
                    TS.setMODDestreza(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaConstituicao.setVisible(true);
                    break;
                case "Inteligência":
                    TS.setInteligencia(TS.getDestreza());
                    TS.setMODInteligencia(TS.getMODDestreza());
                    TS.setDestreza(getValorSubstituicaoStatus());
                    TS.setMODDestreza(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaInteligencia.setVisible(true);
                    break;
                case "Sabedoria":
                    TS.setSabedoria(TS.getDestreza());
                    TS.setMODSabedoria(TS.getMODDestreza());
                    TS.setDestreza(getValorSubstituicaoStatus());
                    TS.setMODDestreza(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaSabedoria.setVisible(true);
                    break;
                case "Carisma":
                    TS.setCarisma(TS.getDestreza());
                    TS.setMODCarisma(TS.getMODDestreza());
                    TS.setDestreza(getValorSubstituicaoStatus());
                    TS.setMODDestreza(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaCarisma.setVisible(true);
                    break;
            }
        }
    }
    public void trocarConstituicao (){
        if(isTrocaDisponivel()){
            setValorSubstituicaoStatus(TS.getConstituicao());
            setValorSubstituicaoModStatus(TS.getMODConstituicao());
            setTrocaDisponivel(false);
            setStatusTroca("Constituição");
            btTrocaConstituicao.setVisible(false);
        }else{
            switch(getStatusTroca()){
                case "Destreza":
                    TS.setDestreza(TS.getConstituicao());
                    TS.setMODDestreza(TS.getMODConstituicao());
                    TS.setConstituicao(getValorSubstituicaoStatus());
                    TS.setMODConstituicao(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaDestreza.setVisible(true);
                    break;
                case "Força":
                    TS.setForca(TS.getConstituicao());
                    TS.setMODForca(TS.getMODConstituicao());
                    TS.setConstituicao(getValorSubstituicaoStatus());
                    TS.setMODConstituicao(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaForca.setVisible(true);
                    break;
                case "Inteligência":
                    TS.setInteligencia(TS.getConstituicao());
                    TS.setMODInteligencia(TS.getMODConstituicao());
                    TS.setConstituicao(getValorSubstituicaoStatus());
                    TS.setMODConstituicao(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaInteligencia.setVisible(true);
                    break;
                case "Sabedoria":
                    TS.setSabedoria(TS.getConstituicao());
                    TS.setMODSabedoria(TS.getMODConstituicao());
                    TS.setConstituicao(getValorSubstituicaoStatus());
                    TS.setMODConstituicao(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaSabedoria.setVisible(true);
                    break;
                case "Carisma":
                    TS.setCarisma(TS.getConstituicao());
                    TS.setMODCarisma(TS.getMODConstituicao());
                    TS.setConstituicao(getValorSubstituicaoStatus());
                    TS.setMODConstituicao(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaCarisma.setVisible(true);
                    break;
            }
        }
    }
    public void trocarInteligencia (){
        if(isTrocaDisponivel()){
            setValorSubstituicaoStatus(TS.getInteligencia());
            setValorSubstituicaoModStatus(TS.getMODInteligencia());
            setTrocaDisponivel(false);
            setStatusTroca("Inteligência");
            btTrocaInteligencia.setVisible(false);
        }else{
            switch(getStatusTroca()){
                case "Destreza":
                    TS.setDestreza(TS.getInteligencia());
                    TS.setMODDestreza(TS.getMODInteligencia());
                    TS.setInteligencia(getValorSubstituicaoStatus());
                    TS.setMODInteligencia(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaDestreza.setVisible(true);
                    break;
                case "Constituição":
                    TS.setConstituicao(TS.getInteligencia());
                    TS.setMODConstituicao(TS.getMODInteligencia());
                   TS.setInteligencia(getValorSubstituicaoStatus());
                    TS.setMODInteligencia(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaConstituicao.setVisible(true);
                    break;
                case "Força":
                    TS.setForca(TS.getInteligencia());
                    TS.setMODForca(TS.getMODInteligencia());
                    TS.setInteligencia(getValorSubstituicaoStatus());
                    TS.setMODInteligencia(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaForca.setVisible(true);
                    break;
                case "Sabedoria":
                    TS.setSabedoria(TS.getInteligencia());
                    TS.setMODSabedoria(TS.getMODInteligencia());
                    TS.setInteligencia(getValorSubstituicaoStatus());
                    TS.setMODInteligencia(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaSabedoria.setVisible(true);
                    break;
                case "Carisma":
                    TS.setCarisma(TS.getInteligencia());
                    TS.setMODCarisma(TS.getMODInteligencia());
                    TS.setInteligencia(getValorSubstituicaoStatus());
                    TS.setMODInteligencia(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaCarisma.setVisible(true);
                    break;
            }
        }
    }
    public void trocarSabedoria (){
        if(isTrocaDisponivel()){
            setValorSubstituicaoStatus(TS.getSabedoria());
            setValorSubstituicaoModStatus(TS.getMODSabedoria());
            setTrocaDisponivel(false);
            setStatusTroca("Sabedoria");
            btTrocaSabedoria.setVisible(false);
        }else{
            switch(getStatusTroca()){
                case "Destreza":
                    TS.setDestreza(TS.getSabedoria());
                    TS.setMODDestreza(TS.getMODSabedoria());
                    TS.setSabedoria(getValorSubstituicaoStatus());
                    TS.setMODSabedoria(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaDestreza.setVisible(true);
                    break;
                case "Constituição":
                    TS.setConstituicao(TS.getSabedoria());
                    TS.setMODConstituicao(TS.getMODSabedoria());
                    TS.setSabedoria(getValorSubstituicaoStatus());
                    TS.setMODSabedoria(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaConstituicao.setVisible(true);
                    break;
                case "Inteligência":
                    TS.setInteligencia(TS.getSabedoria());
                    TS.setMODInteligencia(TS.getMODSabedoria());
                    TS.setSabedoria(getValorSubstituicaoStatus());
                    TS.setMODSabedoria(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaInteligencia.setVisible(true);
                    break;
                case "Força":
                    TS.setForca(TS.getSabedoria());
                    TS.setMODForca(TS.getMODSabedoria());
                    TS.setSabedoria(getValorSubstituicaoStatus());
                    TS.setMODSabedoria(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaForca.setVisible(true);
                    break;
                case "Carisma":
                    TS.setCarisma(TS.getSabedoria());
                    TS.setMODCarisma(TS.getMODSabedoria());
                    TS.setSabedoria(getValorSubstituicaoStatus());
                    TS.setMODSabedoria(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaCarisma.setVisible(true);
                    break;
            }
        }
    }
    public void trocarCarisma (){
        if(isTrocaDisponivel()){
            setValorSubstituicaoStatus(TS.getCarisma());
            setValorSubstituicaoModStatus(TS.getMODCarisma());
            setTrocaDisponivel(false);
            setStatusTroca("Carisma");
            btTrocaCarisma.setVisible(false);
        }else{
            switch(getStatusTroca()){
                case "Destreza":
                    TS.setDestreza(TS.getCarisma());
                    TS.setMODDestreza(TS.getMODCarisma());
                    TS.setCarisma(getValorSubstituicaoStatus());
                    TS.setMODCarisma(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaDestreza.setVisible(true);
                    break;
                case "Constituição":
                    TS.setConstituicao(TS.getCarisma());
                    TS.setMODConstituicao(TS.getMODCarisma());
                    TS.setCarisma(getValorSubstituicaoStatus());
                    TS.setMODCarisma(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaConstituicao.setVisible(true);
                    break;
                case "Inteligência":
                    TS.setInteligencia(TS.getCarisma());
                    TS.setMODInteligencia(TS.getMODCarisma());
                    TS.setCarisma(getValorSubstituicaoStatus());
                    TS.setMODCarisma(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaInteligencia.setVisible(true);
                    break;
                case "Sabedoria":
                    TS.setSabedoria(TS.getCarisma());
                    TS.setMODSabedoria(TS.getMODCarisma());
                    TS.setCarisma(getValorSubstituicaoStatus());
                    TS.setMODCarisma(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaSabedoria.setVisible(true);
                    break;
                case "Força":
                    TS.setForca(TS.getCarisma());
                    TS.setMODForca(TS.getMODCarisma());
                    TS.setCarisma(getValorSubstituicaoStatus());
                    TS.setMODCarisma(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaForca.setVisible(true);
                    break;
            }
        }
    }
    
    public void atualizarStatus(){
        lvStatus.getItems().clear(); 
        Status = TS.OrganizarInfo();
        lvStatus.getItems().addAll(Status);
    }
    
    public String escolherUma(String [] sr) {
		return sr [random.nextInt(sr.length)];
    }
    
    public int getValorSubstituicaoStatus() {
        return ValorSubstituicaoStatus;
    }
    public void setValorSubstituicaoStatus(int ValorSubstituicaoStatus) {
        this.ValorSubstituicaoStatus = ValorSubstituicaoStatus;
    }

    public int getValorSubstituicaoModStatus() {
        return ValorSubstituicaoModStatus;
    }
    public void setValorSubstituicaoModStatus(int ValorSubstituicaoModStatus) {
        this.ValorSubstituicaoModStatus = ValorSubstituicaoModStatus;
    }
    
    public boolean isTrocaDisponivel() {
        return trocaDisponivel;
    }
    public void setTrocaDisponivel(boolean trocaDisponivel) {
        this.trocaDisponivel = trocaDisponivel;
    }

    public String getStatusTroca() {
        return StatusTroca;
    }
    public void setStatusTroca(String StatusTroca) {
        this.StatusTroca = StatusTroca;
    }
      
}
