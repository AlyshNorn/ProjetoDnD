package dndinterfacefx;

public class BonusDeRacaESubRaca {
    switch(bxRaca.getValue()){
                case "Força":
                    TS.setForca(TS.getDestreza());
                    TS.setMODForca(TS.getMODDestreza());
                    TS.setDestreza(getValorSubstituicaoStatus());
                    TS.setMODDestreza(getValorSubstituicaoModStatus());
                    atualizarStatus();
                    setTrocaDisponivel(true);
                    btTrocaForca.setVisible(true);
}
